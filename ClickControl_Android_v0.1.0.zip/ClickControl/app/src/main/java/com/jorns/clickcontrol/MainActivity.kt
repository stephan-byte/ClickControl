package com.jorns.clickcontrol

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ClickControlScreen() }
    }
}

@Composable
private fun ClickControlScreen() {
    val context = LocalContext.current
    var clicks by remember { mutableIntStateOf(0) }
    var speed by remember { mutableFloatStateOf(100f) }
    var url by remember { mutableStateOf("https://www.youtube.com/") }

    MaterialTheme {
        Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(
                modifier = Modifier.fillMaxSize().padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                Text("ClickControl", style = MaterialTheme.typography.headlineLarge)
                Text("Lokaler Klick-Simulator – keine automatisierten Plattform-Aufrufe")
                Text("Testzähler", style = MaterialTheme.typography.titleMedium)
                Text(clicks.toString(), style = MaterialTheme.typography.displayLarge)
                Button(onClick = { clicks++ }, modifier = Modifier.fillMaxWidth()) { Text("Einzelschritt testen") }
                OutlinedButton(onClick = { clicks += 100 }, modifier = Modifier.fillMaxWidth()) { Text("100 Testklicks simulieren") }
                OutlinedButton(onClick = { clicks = 0 }, modifier = Modifier.fillMaxWidth()) { Text("Zähler zurücksetzen") }
                Text("Geschwindigkeit: ${speed.toInt()}")
                Slider(value = speed, onValueChange = { speed = it }, valueRange = 10f..1000f)
                OutlinedTextField(value = url, onValueChange = { url = it }, label = { Text("Video- oder Plattform-Link") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Button(onClick = {
                    val parsed = runCatching { Uri.parse(url.trim()) }.getOrNull()
                    if (parsed != null && (parsed.scheme == "https" || parsed.scheme == "http") && !parsed.host.isNullOrBlank()) {
                        context.startActivity(Intent(Intent.ACTION_VIEW, parsed))
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text("Link extern öffnen") }
                OutlinedButton(onClick = {
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, url.trim())
                    }
                    context.startActivity(Intent.createChooser(send, "Link teilen"))
                }, modifier = Modifier.fillMaxWidth()) { Text("Link teilen") }
                Text("Hinweis: Der Zähler simuliert nur lokale Testwerte. Er erzeugt keine YouTube-Aufrufe, Likes oder Reichweite.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
