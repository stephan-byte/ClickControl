# ClickControl – Android prototype 0.1.0

ClickControl is a local Android test utility. It includes a local counter, a 100-step simulation button, a 10–1,000 speed setting, and actions to open or share a user-provided HTTP(S) link through Android's standard chooser/browser.

## Important scope boundary
The counter is local simulation only. The app does **not** automate clicks on YouTube or other platforms and does not generate views, likes, subscribers, ad interactions, or engagement. Platform links are opened/shared using Android intents.

## Build
- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21
- Java 17
- compileSdk 35 / minSdk 23

Run `gradle assembleDebug` in an environment with Android SDK 35 installed, or use the included GitHub Actions workflow. The workflow publishes the debug APK as an artifact.
